const ENV = {
    // API_URL: 'https://moodbox.smartduuka.com',
    API_URL: 'https://restaurant.smartduuka.com',
    // API_URL: 'https://smartduuka-restaurant.test',
    API_KEY: process.env.MIX_API_KEY,
    GOOGLE_MAP_KEY: process.env.MIX_GOOGLE_MAP_KEY,
    DEMO: process.env.MIX_DEMO
};
export default ENV;
